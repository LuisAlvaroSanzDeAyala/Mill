declare module "@salesforce/apex/FullCalendarService.fetchAllEvents" {
  export default function fetchAllEvents(): Promise<any>;
}
