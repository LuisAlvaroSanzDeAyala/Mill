declare module "@salesforce/apex/getAccountLWC.getAccountLWC" {
  export default function getAccountLWC(): Promise<any>;
}
