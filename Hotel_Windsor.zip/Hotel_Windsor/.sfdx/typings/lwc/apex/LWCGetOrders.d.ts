declare module "@salesforce/apex/LWCGetOrders.LWCGetOrders" {
  export default function LWCGetOrders(): Promise<any>;
}
