declare module "@salesforce/schema/AssignmentRule.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/AssignmentRule.Name" {
  const Name:string;
  export default Name;
}
declare module "@salesforce/schema/AssignmentRule.SobjectType" {
  const SobjectType:string;
  export default SobjectType;
}
declare module "@salesforce/schema/AssignmentRule.Active" {
  const Active:boolean;
  export default Active;
}
declare module "@salesforce/schema/AssignmentRule.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/AssignmentRule.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/AssignmentRule.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/AssignmentRule.LastModifiedBy" {
  const LastModifiedBy:any;
  export default LastModifiedBy;
}
declare module "@salesforce/schema/AssignmentRule.LastModifiedById" {
  const LastModifiedById:any;
  export default LastModifiedById;
}
declare module "@salesforce/schema/AssignmentRule.LastModifiedDate" {
  const LastModifiedDate:any;
  export default LastModifiedDate;
}
declare module "@salesforce/schema/AssignmentRule.SystemModstamp" {
  const SystemModstamp:any;
  export default SystemModstamp;
}
