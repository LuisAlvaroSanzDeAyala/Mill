declare module "@salesforce/schema/AuraDefinitionBundleInfo.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/AuraDefinitionBundleInfo.DurableId" {
  const DurableId:string;
  export default DurableId;
}
declare module "@salesforce/schema/AuraDefinitionBundleInfo.AuraDefinitionBundleId" {
  const AuraDefinitionBundleId:string;
  export default AuraDefinitionBundleId;
}
declare module "@salesforce/schema/AuraDefinitionBundleInfo.ApiVersion" {
  const ApiVersion:number;
  export default ApiVersion;
}
declare module "@salesforce/schema/AuraDefinitionBundleInfo.DeveloperName" {
  const DeveloperName:string;
  export default DeveloperName;
}
declare module "@salesforce/schema/AuraDefinitionBundleInfo.NamespacePrefix" {
  const NamespacePrefix:string;
  export default NamespacePrefix;
}
