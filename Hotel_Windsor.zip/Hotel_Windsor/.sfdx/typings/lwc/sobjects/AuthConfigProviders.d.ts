declare module "@salesforce/schema/AuthConfigProviders.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/AuthConfigProviders.IsDeleted" {
  const IsDeleted:boolean;
  export default IsDeleted;
}
declare module "@salesforce/schema/AuthConfigProviders.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/AuthConfigProviders.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/AuthConfigProviders.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/AuthConfigProviders.LastModifiedDate" {
  const LastModifiedDate:any;
  export default LastModifiedDate;
}
declare module "@salesforce/schema/AuthConfigProviders.LastModifiedBy" {
  const LastModifiedBy:any;
  export default LastModifiedBy;
}
declare module "@salesforce/schema/AuthConfigProviders.LastModifiedById" {
  const LastModifiedById:any;
  export default LastModifiedById;
}
declare module "@salesforce/schema/AuthConfigProviders.SystemModstamp" {
  const SystemModstamp:any;
  export default SystemModstamp;
}
declare module "@salesforce/schema/AuthConfigProviders.AuthConfig" {
  const AuthConfig:any;
  export default AuthConfig;
}
declare module "@salesforce/schema/AuthConfigProviders.AuthConfigId" {
  const AuthConfigId:any;
  export default AuthConfigId;
}
declare module "@salesforce/schema/AuthConfigProviders.AuthProvider" {
  const AuthProvider:any;
  export default AuthProvider;
}
declare module "@salesforce/schema/AuthConfigProviders.AuthProviderId" {
  const AuthProviderId:any;
  export default AuthProviderId;
}
