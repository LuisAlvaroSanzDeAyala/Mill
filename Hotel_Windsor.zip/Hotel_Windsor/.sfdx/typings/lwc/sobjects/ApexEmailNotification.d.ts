declare module "@salesforce/schema/ApexEmailNotification.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/ApexEmailNotification.IsDeleted" {
  const IsDeleted:boolean;
  export default IsDeleted;
}
declare module "@salesforce/schema/ApexEmailNotification.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/ApexEmailNotification.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/ApexEmailNotification.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/ApexEmailNotification.LastModifiedDate" {
  const LastModifiedDate:any;
  export default LastModifiedDate;
}
declare module "@salesforce/schema/ApexEmailNotification.LastModifiedBy" {
  const LastModifiedBy:any;
  export default LastModifiedBy;
}
declare module "@salesforce/schema/ApexEmailNotification.LastModifiedById" {
  const LastModifiedById:any;
  export default LastModifiedById;
}
declare module "@salesforce/schema/ApexEmailNotification.SystemModstamp" {
  const SystemModstamp:any;
  export default SystemModstamp;
}
declare module "@salesforce/schema/ApexEmailNotification.User" {
  const User:any;
  export default User;
}
declare module "@salesforce/schema/ApexEmailNotification.UserId" {
  const UserId:any;
  export default UserId;
}
declare module "@salesforce/schema/ApexEmailNotification.Email" {
  const Email:string;
  export default Email;
}
