declare module "@salesforce/resourceUrl/FullCalendarJS" {
    var FullCalendarJS: string;
    export default FullCalendarJS;
}